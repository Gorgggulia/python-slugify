// Простий статичний сервер для тестованого застосунку.
// Каталог сайту задається змінною SITE_DIR (за замовчуванням "site").
const http = require('http');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, process.env.SITE_DIR || 'site');
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript' };
http.createServer((req, res) => {
  const rel = decodeURIComponent(req.url.split('?')[0]);
  const file = path.join(root, rel === '/' ? 'index.html' : rel);
  if (!file.startsWith(root) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404); return res.end('Not found');
  }
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}).listen(4173, '127.0.0.1', () => console.log('Serving ' + root + ' on http://127.0.0.1:4173'));
