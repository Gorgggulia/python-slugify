const { test, expect } = require('@playwright/test');

// Робить знімок усієї сторінки зі стабілізацією:
//  - чекаємо завантаження шрифтів;
//  - вимикаємо CSS-анімації (пульсація бейджа);
//  - маскуємо динамічний годинник у підвалі.
async function snap(page, name) {
  await page.evaluate(() => document.fonts.ready);
  await expect(page).toHaveScreenshot(name, {
    fullPage: true,
    animations: 'disabled',
    mask: [page.locator('#clock')],
  });
}

test.describe('Скріншотні тести книгарні', () => {
  test('1. Головна сторінка', async ({ page }) => {
    await page.goto('/index.html');
    await snap(page, 'home.png');
  });

  test('2. Каталог книг', async ({ page }) => {
    await page.goto('/catalog.html');
    await snap(page, 'catalog.png');
  });

  test('3. Картка товару', async ({ page }) => {
    await page.goto('/product.html');
    await snap(page, 'product.png');
  });

  test('4. Кошик', async ({ page }) => {
    await page.goto('/cart.html');
    await snap(page, 'cart.png');
  });

  test('5. Сторінка входу', async ({ page }) => {
    await page.goto('/login.html');
    await snap(page, 'login.png');
  });

  test('6. Вхід: помилки валідації', async ({ page }) => {
    await page.goto('/login.html');
    await page.locator('form button[type=submit]').click();
    await expect(page.locator('.field.invalid')).toHaveCount(2);
    await snap(page, 'login-errors.png');
  });

  test('7. Контакти', async ({ page }) => {
    await page.goto('/contact.html');
    await snap(page, 'contact.png');
  });

  test('8. Про нас', async ({ page }) => {
    await page.goto('/about.html');
    await snap(page, 'about.png');
  });
});
