const { defineConfig, devices } = require('@playwright/test');

const PORT = 4173;

module.exports = defineConfig({
  testDir: './tests',
  fullyParallel: true,
  retries: 0, // жодних повторів, щоб нестабільність тестів не маскувалась
  reporter: [['list'], ['html', { open: 'never' }]],
  expect: {
    toHaveScreenshot: {
      maxDiffPixels: 0, // знімки мають збігатися піксель у піксель
      threshold: 0.2,   // допуск на різницю кольору одного пікселя
    },
  },
  use: {
    baseURL: `http://127.0.0.1:${PORT}`,
    locale: 'uk-UA',
    timezoneId: 'Europe/Kyiv',
    colorScheme: 'light',
    deviceScaleFactor: 1,
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'], viewport: { width: 1280, height: 720 } } },
  ],
  webServer: {
    command: 'node server.js', // каталог сайту береться зі змінної SITE_DIR
    url: `http://127.0.0.1:${PORT}/index.html`,
    reuseExistingServer: false,
  },
});
