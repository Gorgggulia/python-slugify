(function () {
  var path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('nav a').forEach(function (a) {
    if (a.getAttribute('href') === path) a.classList.add('active');
  });
  var clock = document.getElementById('clock');
  if (clock) {
    var tick = function () { clock.textContent = 'Час на сайті: ' + new Date().toLocaleTimeString('uk-UA'); };
    tick();
    setInterval(tick, 1000);
  }
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var ok = true;
      form.querySelectorAll('[required]').forEach(function (input) {
        var box = input.closest('.field');
        var bad = !input.value.trim() || (input.type === 'email' && input.value.indexOf('@') < 1);
        box.classList.toggle('invalid', bad);
        box.querySelector('.field-error').hidden = !bad;
        if (bad) ok = false;
      });
      form.querySelector('.form-ok').hidden = !ok;
    });
  });
})();
